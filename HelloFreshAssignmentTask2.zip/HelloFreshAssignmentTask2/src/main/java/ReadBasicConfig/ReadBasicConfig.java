package ReadBasicConfig;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ReadBasicConfig{

	private static Properties properties = new Properties();
	private static InputStream fileInput = null;
	private String config ;
	private static ReadBasicConfig instance;
	static String Config_Path=System.getProperty("user.dir") + "/src/test/resources/config.properties";
	/**
	 * A private Constructor prevents any other class from instantiating.
	 */
	private ReadBasicConfig(){
		try {;
		
			
			String customer = System.getProperty("customer");
			fileInput = new FileInputStream(Config_Path);
			properties.load(fileInput);
		} 
		catch (Exception ex) {
			ex.printStackTrace();
		}
		finally{
			if(fileInput != null){
				try {
					fileInput.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * Singleton Helper Class.
	 */
	private static class ReadConfigFromPropertiesHelper
	{
		private static final ReadBasicConfig instance = new ReadBasicConfig();
		
	}
	
	/**
	 * Creating instance variable.
	 */
	public static ReadBasicConfig getInstance(){
		
		return ReadConfigFromPropertiesHelper.instance;
	
	}
	
	public static void returnProperties() {
		try {
			fileInput = new FileInputStream(Config_Path);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			properties.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public String readPropertiesforConfig(String config) throws IOException {
		returnProperties();
		String value = null;
		value = properties.getProperty(config);
        
		if(value != null && !value.isEmpty()){
        	return value.trim();
//        	System.out.println("Value is: " +value);
        }else{
        	System.out.println("config value is null");
        }
		return value;
        
    }

	public String getConfig() {
		return config;
	}

	public void setConfig(String config) {
		this.config = config;
	}
}
