package Task5;

import java.io.IOException;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import ReadBasicConfig.ReadBasicConfig;

public class DeleteBooking {
	
	private ReadBasicConfig readConfig = ReadBasicConfig.getInstance();

	@Test
	public void DeletebookingDetails() throws ParseException, IOException
	{
		System.out.println("Task 5: DeleteBooking: Test that booking has been deleted.\n");
		String apiURL = readConfig.readPropertiesforConfig("apiUrl");
		String bookingID = readConfig.readPropertiesforConfig("bookingID");
		RestAssured.baseURI = apiURL;
		
		RequestSpecification request = RestAssured.given();
		JSONObject requestParams = new JSONObject();
		JSONObject childData = new JSONObject();
		
			//execute delete the request and check the response
			Response response = request.delete(RestAssured.baseURI);
			System.out.println("Api url is: "+RestAssured.baseURI+bookingID);

			int statusCode = response.getStatusCode();
			if (statusCode!=405) {
			String responseBody = response.getBody().asString();
			System.out.println("Response Body is =>  " + responseBody);
			Assert.assertEquals(statusCode, 200);
			}
			else
				System.out.println("UnAuthorized access and status code return is:"+ 405 + "\n");
			
		}
}
