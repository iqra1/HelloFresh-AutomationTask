package DataProvider;
import static io.restassured.RestAssured.get;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import org.json.simple.parser.ParseException;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import ReadBasicConfig.ReadBasicConfig;

public class BookingResponseData {

	private ReadBasicConfig readConfig = ReadBasicConfig.getInstance();

	@Test
	public void GetStatusCode() throws IOException{

		//To get response code

		String URL = readConfig.readPropertiesforConfig("apiUrl");
		int code=get(URL).getStatusCode();
		System.out.print("Status code is:"+code+"\n");
		Assert.assertEquals(code,200,"Response does not received!");
	}
	
	public int getBookingId() throws ParseException, IOException {

		String data=GetData();
		JsonObject jsonObject = new JsonParser().parse(data).getAsJsonObject();
		JsonArray bookings = jsonObject.getAsJsonArray("bookings");
		ArrayList<Integer> bookingids = new ArrayList<Integer>();
		for (int i = 0; i < bookings.size(); i++) {
			bookingids.add(bookings.get(i).getAsJsonObject().get("bookingid").getAsInt());
		}
		
		return bookingids.get(1);
	}
	
	public  String GetData() throws ParseException, IOException	
	{
		//To get response data
		String URL = readConfig.readPropertiesforConfig("apiUrl");
		String data=get(URL).asString();
		return data;
	}

	public  String GetDataByID() throws ParseException, IOException	
	{
		//To get response data by id
		String URL = readConfig.readPropertiesforConfig("apiUrl");
		int bookingID = getBookingId();
		String data=get(URL+bookingID).asString();
		return data;
	}
}
