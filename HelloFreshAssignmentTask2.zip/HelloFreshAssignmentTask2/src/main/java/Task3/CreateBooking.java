package Task3;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Random;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import DataProvider.BookingResponseData;
import ReadBasicConfig.ReadBasicConfig;


public class CreateBooking {

	BookingResponseData response = new BookingResponseData();
	private ReadBasicConfig readConfig = ReadBasicConfig.getInstance();

	@Test
	public void AddBooking() throws ParseException, IOException
	{
		System.out.println("Task 3: createBooking: Test that bookings can be created\n");

		RequestSpecification request = RestAssured.given();
		JSONObject requestParams = new JSONObject();
		JSONObject childData = new JSONObject();
		int bookingID=getBookingId();
		String apiURL = readConfig.readPropertiesforConfig("apiUrl");
		String roomCheckin = readConfig.readPropertiesforConfig("roomCheckin");
		String roomCheckout = readConfig.readPropertiesforConfig("roomCheckout");
		String roomID = readConfig.readPropertiesforConfig("roomID");
		RestAssured.baseURI = apiURL;

		if(checkIfValidDates(roomCheckin, roomCheckout)) {

			requestParams.put("bookingid",bookingID);
			requestParams.put("roomid", roomID);
			requestParams.put("firstname", "iqra"); 
			requestParams.put("lastname", "luqman");
			requestParams.put("depositpaid", true);
			requestParams.put("phone", "12345678901");
			requestParams.put("email", "iqra_luqman@hotmail.com");
			childData.put("checkin", roomCheckin);
			childData.put("checkout", roomCheckout);
			requestParams.put("bookingdates", childData);


			// Add a header stating the Request body is a JSON
			request.header("Content-Type", "application/json;charset=UTF-8 ");
			// Add the Json to the body of the request
			request.body(requestParams.toJSONString());
			// Post the request and check the response
			Response response = request.post(RestAssured.baseURI);

			int statusCode = response.getStatusCode();
			String responseBody = response.getBody().asString();
			System.out.println("Room has been booked successfully");
			System.out.println("Response Body is =>  " + responseBody+ "\n");
			Assert.assertEquals(statusCode, 201);

		}
	}

	private boolean checkIfValidDates(String roomCheckin, String roomCheckout) throws ParseException, IOException {

		String roomID = readConfig.readPropertiesforConfig("roomID");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Calendar startCalendar = new GregorianCalendar();
		Calendar endCalendar = new GregorianCalendar();

		String data=response.GetData();
		JsonObject jsonObject = new JsonParser().parse(data).getAsJsonObject();
		JsonArray bookings = jsonObject.getAsJsonArray("bookings");
		List<Date> bookedDates = new ArrayList(); 
		try {
			if (df.parse(roomCheckin).compareTo(df.parse(roomCheckout)) > 0) {
				System.out.println("Please choose checkout date after checkin date");
			} else {
				for (int i = 0; i < bookings.size(); i++) {
					String room_id = bookings.get(i).getAsJsonObject().get("roomid").getAsString();
					if (room_id.equals(roomID)) {
						jsonObject=bookings.get(i).getAsJsonObject().get("bookingdates").getAsJsonObject();
						String checkin = jsonObject.get("checkin").getAsString();
						String checkout = jsonObject.get("checkout").getAsString();

						startCalendar.setTime(df.parse(checkin));
						endCalendar.setTime(df.parse(checkout));

						while (startCalendar.before(endCalendar)) {
							Date result = startCalendar.getTime();
							bookedDates.add(result);
							startCalendar.add(Calendar.DATE, 1);
						}
						bookedDates.add(df.parse(checkout));				
					}
				}

				if(bookedDates.contains(df.parse(roomCheckin))) {
					System.out.println("Room No:"+ roomID +" is already booked, Please choose dates other than the following dates:" + bookedDates +"\n");
					return false;
				} else {
					System.out.println("Room: " + roomID +" is available from start date " + roomCheckin + " to end date " + roomCheckout);
					return true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public int getBookingId() throws ParseException, IOException {

		Random rand = new Random(); 
		int bookingid = rand.nextInt(1000); 
		String data=response.GetData();
		JsonObject jsonObject = new JsonParser().parse(data).getAsJsonObject();
		JsonArray bookings = jsonObject.getAsJsonArray("bookings");
		ArrayList<Integer> bookingids = new ArrayList<Integer>();
		for (int i = 0; i < bookings.size(); i++) {
			bookingids.add(bookings.get(i).getAsJsonObject().get("bookingid").getAsInt());
		}
		for (int i=0; i<bookingids.size(); i++) { 
			for (int element : bookingids) { 
				if (element == bookingid) { 
					getBookingId(); 
				}
				else
					return bookingid;        

			}

		}
		return bookingid;
	}

}
