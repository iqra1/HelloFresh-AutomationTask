package Task4;

import java.io.IOException;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import ReadBasicConfig.ReadBasicConfig;

public class UpdateBooking {
	
	private ReadBasicConfig readConfig = ReadBasicConfig.getInstance();

	@Test
	public void UpdateBookingDetails() throws ParseException, IOException
	{
		System.out.println("Task 4: UpdateBooking: Test that booking has been updated.\n");
		String apiURL = readConfig.readPropertiesforConfig("apiUrl");
		String roomCheckin = readConfig.readPropertiesforConfig("roomCheckin");
		String roomCheckout = readConfig.readPropertiesforConfig("roomCheckout");
		String roomID = readConfig.readPropertiesforConfig("roomID");
		String bookingID = readConfig.readPropertiesforConfig("bookingID");
		RestAssured.baseURI = apiURL;
		
		RequestSpecification request = RestAssured.given();
		JSONObject requestParams = new JSONObject();
		JSONObject childData = new JSONObject();
		

			requestParams.put("bookingid",bookingID);
			requestParams.put("roomid", roomID);
			requestParams.put("firstname", "iqra"); 
			requestParams.put("lastname", "luqman");
			requestParams.put("depositpaid", true);
			requestParams.put("phone", "10005678901");
			requestParams.put("email", "iqra.luqman@hotmail.com");
			childData.put("checkin", roomCheckin);
			childData.put("checkout", roomCheckout);
			requestParams.put("bookingdates", childData);

			// Add a header stating the Request body is a JSON
			request.header("Content-Type", "application/json;charset=UTF-8 ");
			// Add the Json to the body of the request
			request.body(requestParams.toJSONString());
			// Put the request and check the response
			Response response = request.put(RestAssured.baseURI+bookingID);
			System.out.println("Api url is: "+RestAssured.baseURI+bookingID);

			int statusCode = response.getStatusCode();
			if (statusCode!=403) {
			String responseBody = response.getBody().asString();
			System.out.println("Response Body is =>  " + responseBody);
			Assert.assertEquals(statusCode, 200);
			}
			else
				System.out.println("Forbidden access and status code return is:"+ 403 + "\n");
			
		}


}
