package Task2;

import java.io.IOException;
import org.json.simple.parser.ParseException;
import org.testng.annotations.Test;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import DataProvider.BookingResponseData;

public class GetBooking {
	
	BookingResponseData response = new BookingResponseData();
	
	@Test
	public void GetBookingData() throws ParseException, IOException	
	{

		System.out.println("Task 2: getBooking: Test that the data returned for an existing booking matches\n");
		String data=response.GetDataByID();
		JsonObject jsonObject = new JsonParser().parse(data).getAsJsonObject();

		String booking_id = jsonObject.getAsJsonObject().get("bookingid").getAsString();
		System.out.println("\n"+"Bookingid:"+booking_id);

		String room_id = jsonObject.getAsJsonObject().get("roomid").getAsString();
		System.out.println("Roomid:"+room_id);

		String firstname = jsonObject.getAsJsonObject().get("firstname").getAsString();
		System.out.println("Firstname:"+firstname);

		String lastname = jsonObject.getAsJsonObject().get("lastname").getAsString();
		System.out.println("Lastname:"+lastname);

		String depositid =jsonObject.getAsJsonObject().get("depositpaid").getAsString();
		System.out.println("Depositpaid:"+depositid);

		String checkin = jsonObject.getAsJsonObject().get("bookingdates").getAsJsonObject().get("checkin").getAsString();
		System.out.println("checkin:"+checkin);

		String checkout = jsonObject.getAsJsonObject().get("bookingdates").getAsJsonObject().get("checkout").getAsString();
		System.out.println("checkout:"+checkout+"\n");


	}

}
