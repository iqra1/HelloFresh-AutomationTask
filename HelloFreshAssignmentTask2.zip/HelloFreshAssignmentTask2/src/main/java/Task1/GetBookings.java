package Task1;

import java.io.IOException;
import org.json.simple.parser.ParseException;
import org.testng.annotations.Test;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import DataProvider.BookingResponseData;


public class GetBookings  {

	BookingResponseData response = new BookingResponseData();

	@Test
	public void GetBookingsData() throws ParseException, IOException	
	{

		System.out.println("Task1: getBookings: Test that at least 2 existing bookings are returned in the response.\n");
		String data=response.GetData();
		JsonObject jsonObject = new JsonParser().parse(data).getAsJsonObject();
		JsonArray arr1 = jsonObject.getAsJsonArray("bookings");
		int Bookingcount=2;
		for (int i = 0; i < Bookingcount; i++) {

			String booking_id = arr1.get(i).getAsJsonObject().get("bookingid").getAsString();
			System.out.println("\n"+"Bookingid:"+booking_id);

			String room_id = arr1.get(i).getAsJsonObject().get("roomid").getAsString();
			System.out.println("Roomid:"+room_id);

			String firstname = arr1.get(i).getAsJsonObject().get("firstname").getAsString();
			System.out.println("Firstname:"+firstname);

			String lastname = arr1.get(i).getAsJsonObject().get("lastname").getAsString();
			System.out.println("Lastname:"+lastname);

			String depositid = arr1.get(i).getAsJsonObject().get("depositpaid").getAsString();
			System.out.println("Depositpaid:"+depositid);

			String checkin = arr1.get(i).getAsJsonObject().get("bookingdates").getAsJsonObject().get("checkin").getAsString();
			System.out.println("checkin:"+checkin);

			String checkout = arr1.get(i).getAsJsonObject().get("bookingdates").getAsJsonObject().get("checkout").getAsString();
			System.out.println("checkout:"+checkout+"\n");


		}


	}
}
