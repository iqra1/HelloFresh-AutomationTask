package Hello_Fresh.enums;
public enum ConfigPath {
	 

	BASIC_CONFIG(System.getProperty("user.dir") + "/src/main/config/BasicConfig/Hello-fresh.properties");
	
	private String path;
	
	public String getConfigPath() {
		return path;
	}
	
	private static String getCustomer(){
		return System.getProperty("customer");
	}
	
	ConfigPath(String str) {
		path = str;
	}

}



