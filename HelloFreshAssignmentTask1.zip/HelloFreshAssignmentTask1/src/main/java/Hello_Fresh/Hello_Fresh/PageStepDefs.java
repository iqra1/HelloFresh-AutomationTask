package Hello_Fresh.Hello_Fresh;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Hello_Fresh.config.ReadBasicConfig;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

/**
 * Hello world!
 *
 */
public class PageStepDefs 
{
	private String URLFromProps;
	private ReadBasicConfig readConfig = ReadBasicConfig.getInstance();
	public static WebDriver webdriver = null;
	WebDriverWait wait;
	private static Logger log = LogManager.getLogger(PageStepDefs.class);
	String firefoxBinary = "/Applications/Firefox2.app/Contents/MacOS/firefox";
	String chromeDriverPath = "src/main/java/Hello_Fresh/chromedriver/chromedriver";
	

	public PageStepDefs() throws IOException {

	}
	
	@Before
	public void setupbrowser(){
		String browserName = System.getProperty("browser");
		log.info("Browser is: " + browserName);
			if (browserName.toLowerCase().equals("googlechrome")) {
				System.setProperty("webdriver.chrome.driver", chromeDriverPath);
				webdriver = new ChromeDriver();
				log.info("Browser is googleChrome");
				webdriver.manage().window().maximize();
	
			} else if (browserName.toLowerCase().equals("firefox")) {
				DesiredCapabilities cap = new DesiredCapabilities();
				cap.setCapability("firefox_binary",firefoxBinary);
				
				webdriver = new FirefoxDriver(cap);
				log.info("Browser is Firefox");
				webdriver.manage().window().maximize();
	
				}
	
	}
	
	@Given("^I browse to the (.+) page$")
	public void openWebPage(String path) {
		try {
			URLFromProps = readConfig.readPropertiesforConfig(path);
			log.info(path);
				log.info("Opening " + URLFromProps);
				webdriver.get(URLFromProps);
				webdriver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
				log.info("System wait for 60 Seconds for "+ webdriver.getCurrentUrl() + " to load");
			
		} catch (IOException e) {
			log.error("Exception" + e);
		}

	}
	
	@And("^User clicks on the button (.+) by className$")
	public void clickWebElementByClassName(String buttonClassName) throws IOException {
		String buttonPath = readConfig.readPropertiesforConfig(buttonClassName);
		webdriver.findElement(By.className(buttonPath)).click();
		//log.info("Button Text ⇓: "+webdriver.findElement(By.className(buttonPath)).getText());
		log.info("Button X-Path ⇑: " + buttonPath);
		
	}
	
	@And("^User clicks on the button (.+) by ID$")
	public void clickWebElementByID(String buttonID) throws IOException {
		String buttonPath = readConfig.readPropertiesforConfig(buttonID);
		webdriver.findElement(By.id(buttonPath)).click();
//		log.info("Button Text ⇓: "+webdriver.findElement(By.id(buttonPath)).getText());
//		log.info("Button X-Path ⇑: " + buttonPath);
	}
	
	@And("^User clicks on the button (.+) by LinkText$")
	public void clickWebElementByLinkText(String buttonID) throws IOException {
		String buttonPath = readConfig.readPropertiesforConfig(buttonID);
		webdriver.findElement(By.linkText(buttonPath)).click();
//		log.info("Button Text ⇓: "+webdriver.findElement(By.id(buttonPath)).getText());
//		log.info("Button X-Path ⇑: " + buttonPath);
	}
	
	@And("^User clicks on the link (.+) by Xpath$")
	public void clickWebElementByXpath(String buttonID) throws IOException {
		String buttonPath = readConfig.readPropertiesforConfig(buttonID);
		webdriver.findElement(By.xpath(buttonPath)).click();
//		log.info("Button Text ⇓: "+webdriver.findElement(By.id(buttonPath)).getText());
//		log.info("Button X-Path ⇑: " + buttonPath);
	}
	
	@And("^User clicks on the link (.+) by Name$")
	public void clickWebElementByName(String buttonID) throws IOException {
		String buttonPath = readConfig.readPropertiesforConfig(buttonID);
		webdriver.findElement(By.name(buttonPath)).click();
//		log.info("Button Text ⇓: "+webdriver.findElement(By.id(buttonPath)).getText());
//		log.info("Button X-Path ⇑: " + buttonPath);
	}
	
	
	@And("^I enter (.+) in the (.+) field$")
	public void inputText(String inputText, String idOfTextfield) throws IOException {
		String textFromProp = readConfig.readPropertiesforConfig(inputText);
		WebElement textfield = webdriver.findElement(By.id(readConfig.readPropertiesforConfig(idOfTextfield)));
		textfield.clear();
		textfield.sendKeys(textFromProp);
		log.info("textFromProp-- Input: " + textFromProp);
		log.info("textFromProp-- Xpath: " + textfield);
	}
	
	@And("^User enter random (.+) in the (.+) field$")
	public void inputRandomEmailIntoField(String inputRandomEmailId, String idOfTextfield) throws IOException {
		String randomEmailId= generateRandomEmailId(inputRandomEmailId);
		System.out.println("RandomEmailID: " +randomEmailId);
		WebElement textfield = webdriver.findElement(By.id(readConfig.readPropertiesforConfig(idOfTextfield)));
		textfield.clear();
		textfield.sendKeys(randomEmailId);
		log.info("textFromProperties-- Input: " + randomEmailId);
		log.info("IDFromProperties-- ID: " + textfield);
		System.out.println("textFromProperties-- Input: " + randomEmailId);
		System.out.println("IDFromProperties-- ID: " + textfield);
	}
	
	@And("^I select (.+) from dropdown (.+) by value$")
	public void selectValueFromDropdown(String Value, String path) throws IOException, InterruptedException {
		Select dropdown = null;
		String ValueFromProp = readConfig.readPropertiesforConfig(Value);
		log.info("ValueFromProp: " + ValueFromProp);
		try {
			dropdown = new Select(webdriver.findElement(By.id(readConfig.readPropertiesforConfig(path))));
			log.info("dropdown: " + dropdown);

		} catch (IOException e) {
			log.error(e);
		}
		dropdown.selectByValue(ValueFromProp);
	}
	
	@And("^User select (.+) from dropdown (.+) by visble text$")
	public void selectVisibleTextFromDropdown(String Value, String path) throws IOException, InterruptedException {
		Select dropdown = null;
		String ValueFromProp = readConfig.readPropertiesforConfig(Value);
		log.info("ValueFromProp: " + ValueFromProp);
		try {
			dropdown = new Select(webdriver.findElement(By.id(readConfig.readPropertiesforConfig(path))));
			log.info("dropdown: " + dropdown);

		} catch (IOException e) {
			log.error(e);
		}
		dropdown.selectByVisibleText(ValueFromProp);
	}
	
	
	@And("^I wait for (.+) to visible$")
	public void i_wait_for_element_to_visible(final String classPathOffield) {
		WebDriverWait myWait = new WebDriverWait(webdriver, 10);
		ExpectedCondition<Boolean> conditionToCheck = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
			try {
				return (driver.findElement(By.className(readConfig.readPropertiesforConfig(classPathOffield)))).isDisplayed();
			} catch (IOException e) {
				log.error(e);
			}
			return null;
		}
	};
		myWait.until(conditionToCheck);
	}
	
	@And("^User check for (.+) to be visible by linktext$")
	public void i_check_for_element_to_visible(final String classPathOffield) {
		WebDriverWait myWait = new WebDriverWait(webdriver, 10);
		ExpectedCondition<Boolean> conditionToCheck = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
			try {
				return (driver.findElement(By.linkText(readConfig.readPropertiesforConfig(classPathOffield)))).isDisplayed();
			} catch (IOException e) {
				log.error(e);
			}
			return null;
		}
	};
		myWait.until(conditionToCheck);
	}
	
	@Then("^I should see (.+) (.+) (.+) (.+) (.+) and (.+) on the page$")
	public void confirmTextOnPage(String MainHeading, String FirstName, String LastName, String InfoAccount, String LogoutButton, String CurrentURL) throws IOException{
		String MainHeadingFromProp = readConfig.readPropertiesforConfig(MainHeading);
		System.out.println("Main Heading from properties: " +MainHeadingFromProp);
		String FirstNameFromProp = readConfig.readPropertiesforConfig(FirstName);
		String LastNameFromProp = readConfig.readPropertiesforConfig(LastName);
		String InfoAccountFromProp = readConfig.readPropertiesforConfig(InfoAccount);
		String LogoutButtonFromProp = readConfig.readPropertiesforConfig(LogoutButton);
		String CurrentURLFromProp = readConfig.readPropertiesforConfig(CurrentURL);
		
		//WebElement heading = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h1")));
		WebElement heading = webdriver.findElement(By.cssSelector(MainHeadingFromProp));
		assertEquals(heading.getText(), "MY ACCOUNT");
        assertEquals(webdriver.findElement(By.className("account")).getText(), FirstNameFromProp + " " + LastNameFromProp);
        assertTrue(webdriver.findElement(By.className(InfoAccountFromProp)).getText().contains("Welcome to your account."));
        assertTrue(webdriver.findElement(By.className(LogoutButtonFromProp)).isDisplayed());
        assertTrue(webdriver.getCurrentUrl().contains(CurrentURLFromProp));
	}
	
	@Then("^I should see (.+) (.+) (.+) (.+) (.+) (.+) and (.+) on the page$")
	public void validateTextOnPage(String MainHeading, String ActualHeading, String ShippingStep, String PaymentStep, String OrderText, String ActualLOrderText, String OrderCurrentURL) throws IOException{
		String MainHeadingFromProp = readConfig.readPropertiesforConfig(MainHeading);
		System.out.println("Main Heading from properties: " +MainHeadingFromProp);
		String ActualHeadingFromProp = readConfig.readPropertiesforConfig(ActualHeading);
		String ShippingStepFromProp = readConfig.readPropertiesforConfig(ShippingStep);
		String PaymentStepFromProp = readConfig.readPropertiesforConfig(PaymentStep);
		String OrderTextFromProp = readConfig.readPropertiesforConfig(OrderText);
		String ActualLOrderTextFromProp = readConfig.readPropertiesforConfig(ActualLOrderText);
		String OrderCurrentURLFromProp = readConfig.readPropertiesforConfig(OrderCurrentURL);
		
		//WebElement heading = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h1")));
		WebElement heading = webdriver.findElement(By.cssSelector(MainHeadingFromProp));
		assertEquals(heading.getText(), ActualHeadingFromProp);
		assertTrue(webdriver.findElement(By.xpath(ShippingStepFromProp)).isDisplayed());
        assertTrue(webdriver.findElement(By.xpath(PaymentStepFromProp)).isDisplayed());
        assertTrue(webdriver.findElement(By.xpath(OrderTextFromProp)).getText().contains(ActualLOrderTextFromProp));
        assertTrue(webdriver.getCurrentUrl().contains(OrderCurrentURLFromProp));
	}
	
	public String generateRandomEmailId(String prefixEmail) throws IOException{
		String timestamp = String.valueOf(new Date().getTime());
		String prefix = readConfig.readPropertiesforConfig(prefixEmail);
        String email = prefix + timestamp + "@hf" + timestamp.substring(7) + ".com";
		return email;
	}
	
	@And("^I close the browser$")
	public void quitbrowser(){
		webdriver.quit();
	}
	@After
	public void tearDown(Scenario scenario) {
	    if (scenario.isFailed()) {
	      // Take a screenshot...
	      final byte[] screenshot = ((TakesScreenshot) webdriver).getScreenshotAs(OutputType.BYTES);
	      // embed it in the report.
	      scenario.embed(screenshot, "image/png"); 
	      webdriver.quit();
	    }
	}
	public void quit(){
		webdriver.quit();
	}
	
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
