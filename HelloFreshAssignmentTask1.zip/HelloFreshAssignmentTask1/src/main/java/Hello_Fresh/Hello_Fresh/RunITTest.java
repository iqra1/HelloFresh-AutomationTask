package Hello_Fresh.Hello_Fresh;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

//import com.cucumber.listener.ExtentProperties;
//import com.cucumber.listener.Reporter;

@RunWith(Cucumber.class)
@CucumberOptions(
		//features = {"."},
		features = ".", 
		format = { "pretty",
		        "html:target/site/cucumber-pretty",
		        "json:target/cucumber.json" },
		monochrome = true, 
		tags={"@UserSignUp,@UserlogIn,@UserCheckOut"})

public class RunITTest {

    }

